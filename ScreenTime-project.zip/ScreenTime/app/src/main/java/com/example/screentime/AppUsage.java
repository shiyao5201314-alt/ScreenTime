package com.example.screentime;

import android.graphics.drawable.Drawable;

/**
 * 数据实体类：表示某个 App 在当天的使用汇总数据
 */
public class AppUsage {

    public String packageName;
    public String appName;
    public long totalTimeMillis;   // 当天累计使用时长（毫秒）
    public int launchCount;        // 当天打开次数
    public Drawable icon;          // App 图标，若为 null 则使用占位图

    public AppUsage(String packageName, String appName, long totalTimeMillis, int launchCount, Drawable icon) {
        this.packageName = packageName;
        this.appName = appName;
        this.totalTimeMillis = totalTimeMillis;
        this.launchCount = launchCount;
        this.icon = icon;
    }
}
