package com.example.screentime;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            Fragment target;
            if (id == R.id.nav_home) {
                target = new HomeFragment();
            } else if (id == R.id.nav_stats) {
                target = new StatsFragment();
            } else if (id == R.id.nav_history) {
                target = new HistoryFragment();
            } else {
                target = new SettingsFragment();
            }
            switchFragment(target);
            return true;
        });

        if (savedInstanceState == null) {
            switchFragment(new HomeFragment());
        }

        checkUsagePermission();
    }

    private void switchFragment(Fragment fragment) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.fragment_container, fragment);
        ft.commit();
    }

    /** 检查「使用情况访问」权限，若未授予则引导用户跳转系统设置页 */
    private void checkUsagePermission() {
        if (!UsageStatsHelper.hasUsageStatsPermission(this)) {
            Toast.makeText(this, "请授予「使用情况访问」权限以查看真实数据", Toast.LENGTH_LONG).show();
            try {
                Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            }
        }
    }
}
