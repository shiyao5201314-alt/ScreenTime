# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# Keep the app's model/data classes so field names survive obfuscation
# (harmless here since AppUsage is only used in-process, but this avoids
# surprises if reflection-based code is added later).
-keep class com.example.screentime.AppUsage { *; }

# If you keep the default settings, you can see the fully generated
# usageDescription file at build/outputs/mapping/release/*.txt
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
