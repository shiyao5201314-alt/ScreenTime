# ScreenTime

A native Android app (Java, zero third-party UI libraries) that shows how much
time you've spent in each app today: a total-time card, a 24-hour usage
histogram, and a per-app ranking list — in the style of iOS/Android's built-in
screen-time dashboards.

This repo was originally just an `app/` module (source only, no Gradle
project scaffolding). It's now a complete, buildable Gradle/Android Studio
project that can be opened, built, and packaged into an installable APK or
a Play-Store-ready Android App Bundle (`.aab`).

## Features

- **Home** — today's total screen time, a "vs. yesterday" indicator, a 24-hour
  bar chart (custom `View`, drawn on `Canvas`, no chart library) highlighting
  the peak hour, and a ranked list of apps by usage.
- **Stats** / **History** — placeholder tabs wired up and ready for you to
  extend with weekly/monthly trends or a date-picker history view.
- **Settings** — shows whether the "Usage Access" permission is granted and
  deep-links to the system settings screen to grant it.
- **Demo mode** — if the usage-access permission hasn't been granted yet (or
  the OS returns no data), the app falls back to realistic sample data so the
  UI is never empty on first launch. Turn this off for production in
  `Constants.DEMO_MODE`.

All real data comes from Android's `UsageStatsManager` — no network access,
no analytics, no third-party SDKs.

## Requirements

- Android Studio Hedgehog (2023.1.1) or newer, **or** a command-line JDK 17
  + internet access (Gradle needs to download itself and dependencies on
  first run).
- An Android device or emulator running API 24 (Android 7.0) or newer.

## Getting started

### Option A — Android Studio (recommended)
1. `File > Open` and select this project's root folder.
2. Let Gradle sync. Android Studio will automatically fetch the Gradle
   distribution and generate `gradle/wrapper/gradle-wrapper.jar` if it's
   missing (this repo ships the wrapper's properties/scripts, but not the
   jar itself, since it's a binary — see note below).
3. Run ▶ on a device/emulator.

### Option B — command line
```bash
# One-time only, if gradle-wrapper.jar isn't present yet and you don't want
# to open Android Studio first: install Gradle locally, then run:
gradle wrapper --gradle-version 8.4

# From then on, use the wrapper for everything:
./gradlew assembleDebug          # build a debug APK
./gradlew installDebug           # build + install on a connected device
```

> **Why isn't `gradle-wrapper.jar` included?** It's a small compiled binary,
> not source code, so it isn't something to hand-edit or regenerate offline.
> Both of the options above create it for you on first run — this is a
> completely standard one-time step for any Gradle project and only needs
> network access once.

## Granting the permission

On first launch the app requests the **Usage Access** permission (this can't
be granted via a normal runtime dialog — Android requires it via Settings).
Follow the prompt, or go manually to:
`Settings > Apps > Special app access > Usage access > ScreenTime`.

## Building a release package ("bundling" it)

To produce a real distributable package:

1. **Create a signing key** (once):
   ```bash
   keytool -genkey -v -keystore release.keystore -alias screentime \
     -keyalg RSA -keysize 2048 -validity 10000
   ```
2. **Configure signing**: copy `app/keystore.properties.example` to
   `app/keystore.properties` and fill in the values (this file is
   git-ignored so your secrets stay local).
3. **Build**:
   ```bash
   ./gradlew bundleRelease   # -> app/build/outputs/bundle/release/app-release.aab
   #  or
   ./gradlew assembleRelease # -> app/build/outputs/apk/release/app-release.apk
   ```
   The `.aab` is what you upload to the Google Play Console; the `.apk` can
   be side-loaded directly onto a device for testing or distributed outside
   Play.

If you skip step 1–2, `assembleRelease`/`bundleRelease` still work — they
just produce an **unsigned** artifact, which is fine for local testing but
not for distribution.

## Project structure

```
├── app/
│   ├── build.gradle              # module config, dependencies, signing
│   ├── proguard-rules.pro
│   ├── keystore.properties.example
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/screentime/
│       │   ├── MainActivity.java         # bottom-nav host
│       │   ├── HomeFragment.java         # main dashboard
│       │   ├── StatsFragment.java        # placeholder, extend me
│       │   ├── HistoryFragment.java      # placeholder, extend me
│       │   ├── SettingsFragment.java     # permission status/grant
│       │   ├── UsageStatsHelper.java     # UsageStatsManager queries + demo data
│       │   ├── HistogramView.java        # custom Canvas bar chart
│       │   ├── AppUsage.java             # data model
│       │   ├── AppUsageAdapter.java      # binds ranking list rows
│       │   └── Constants.java            # DEMO_MODE toggle
│       └── res/                          # layouts, drawables, colors, strings
├── build.gradle                  # root/project-level Gradle config
├── settings.gradle
├── gradle.properties
└── gradle/wrapper/gradle-wrapper.properties
```

## Permissions used

| Permission | Why |
|---|---|
| `PACKAGE_USAGE_STATS` | Read per-app foreground usage time (user must grant manually in Settings). |
| `QUERY_ALL_PACKAGES` | Look up app names/icons for every package that shows up in usage data (required on Android 11+ to see apps outside your own visibility scope). |

## Ideas for extending it

- Wire real data into `StatsFragment` (weekly/monthly aggregation already has
  a natural home in `UsageStatsHelper`).
- Add a date picker to `HistoryFragment` and query `UsageStatsManager` for
  arbitrary past days.
- Add per-app time limits + a foreground service/notification to enforce them.
- Add a Room database to cache daily snapshots instead of re-querying
  `UsageEvents` on every launch.

## License

No license was specified with the original source; add one (e.g. MIT/Apache-2.0)
before distributing publicly.
