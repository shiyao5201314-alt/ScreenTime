package com.example.screentime;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/** 设置页：权限状态展示 + 跳转系统设置入口 */
public class SettingsFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView tvStatus = view.findViewById(R.id.tv_permission_status);
        Button btnGrant = view.findViewById(R.id.btn_grant_permission);

        boolean granted = getContext() != null && UsageStatsHelper.hasUsageStatsPermission(getContext());
        tvStatus.setText(granted ? "使用情况访问权限：已授权" : "使用情况访问权限：未授权");

        btnGrant.setOnClickListener(v -> {
            if (getContext() == null) return;
            Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            intent.setData(Uri.parse("package:" + getContext().getPackageName()));
            startActivity(intent);
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        View view = getView();
        if (view != null && getContext() != null) {
            TextView tvStatus = view.findViewById(R.id.tv_permission_status);
            boolean granted = UsageStatsHelper.hasUsageStatsPermission(getContext());
            tvStatus.setText(granted ? "使用情况访问权限：已授权" : "使用情况访问权限：未授权");
        }
    }
}
