package com.example.screentime;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * 应用排行列表绑定工具（不依赖 RecyclerView，纯 LinearLayout 动态填充，
 * 严格遵循"零第三方 / 仅 SDK 原生组件"的约束）。
 */
public class AppUsageAdapter {

    public static void bindList(Context context, LinearLayout container, List<AppUsage> data, long totalTimeToday) {
        container.removeAllViews();
        final long total = Math.max(totalTimeToday, 1L);
        LayoutInflater inflater = LayoutInflater.from(context);

        for (AppUsage item : data) {
            View row = inflater.inflate(R.layout.item_app_usage, container, false);

            ImageView appIcon = row.findViewById(R.id.iv_app_icon);
            TextView appName = row.findViewById(R.id.tv_app_name);
            TextView appDetail = row.findViewById(R.id.tv_app_detail);
            final View progressTrack = row.findViewById(R.id.view_progress_track);
            final View progressFill = row.findViewById(R.id.view_progress_fill);

            appName.setText(item.appName);
            appDetail.setText(item.launchCount + "次 · " + UsageStatsHelper.formatDurationShort(item.totalTimeMillis));

            if (item.icon != null) {
                appIcon.setImageDrawable(item.icon);
            } else {
                appIcon.setImageResource(R.drawable.ic_app_placeholder);
            }

            final float percent = Math.min((float) item.totalTimeMillis / (float) total, 1f);

            // 等待布局完成后再设置进度条填充高度（依赖 track 的真实高度）
            progressTrack.post(new Runnable() {
                @Override
                public void run() {
                    int trackHeight = progressTrack.getHeight();
                    ViewGroup.LayoutParams lp = progressFill.getLayoutParams();
                    lp.height = Math.max((int) (trackHeight * percent), 6);
                    progressFill.setLayoutParams(lp);
                }
            });

            container.addView(row);
        }
    }
}
