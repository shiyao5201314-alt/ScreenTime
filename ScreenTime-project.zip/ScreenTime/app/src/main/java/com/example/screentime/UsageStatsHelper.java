package com.example.screentime;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Process;
import android.util.Log;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 真实数据获取与算法聚合工具类。
 * 使用系统 UsageStatsManager 获取真实的应用前台使用时间戳与时长，
 * 并按“日”“小时”两个维度聚合数据。
 */
public class UsageStatsHelper {

    private static final String TAG = "UsageStatsHelper";

    /** 判断是否已获得「使用情况访问」（PACKAGE_USAGE_STATS）权限 */
    public static boolean hasUsageStatsPermission(Context context) {
        try {
            AppOpsManager appOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
            int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), context.getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            Log.e(TAG, "check permission failed", e);
            return false;
        }
    }

    private static long getStartOfToday() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    /**
     * 获取当天每个 App 的使用汇总（总时长 + 打开次数），按总时长降序排列。
     * 使用 UsageEvents 逐事件计算前台停留时间。
     */
    public static List<AppUsage> getTodayAppUsage(Context context) {
        List<AppUsage> result = new ArrayList<>();
        if (!hasUsageStatsPermission(context)) {
            return Constants.DEMO_MODE ? getDemoAppUsage(context) : result;
        }

        long startTime = getStartOfToday();
        long endTime = System.currentTimeMillis();

        UsageStatsManager usm = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
        UsageEvents events = usm.queryEvents(startTime, endTime);

        Map<String, Long> foregroundStart = new HashMap<>();
        Map<String, Long> totalTime = new HashMap<>();
        Map<String, Integer> launchCount = new HashMap<>();

        UsageEvents.Event event = new UsageEvents.Event();
        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            String pkg = event.getPackageName();
            int type = event.getEventType();

            if (type == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                foregroundStart.put(pkg, event.getTimeStamp());
                Integer c = launchCount.get(pkg);
                launchCount.put(pkg, c == null ? 1 : c + 1);
            } else if (type == UsageEvents.Event.MOVE_TO_BACKGROUND) {
                Long start = foregroundStart.remove(pkg);
                if (start != null) {
                    long duration = event.getTimeStamp() - start;
                    if (duration > 0) {
                        Long t = totalTime.get(pkg);
                        totalTime.put(pkg, (t == null ? 0L : t) + duration);
                    }
                }
            }
        }
        // 仍处于前台（尚未切到后台）的 App，补算到当前时间
        for (Map.Entry<String, Long> entry : foregroundStart.entrySet()) {
            long duration = endTime - entry.getValue();
            if (duration > 0) {
                Long t = totalTime.get(entry.getKey());
                totalTime.put(entry.getKey(), (t == null ? 0L : t) + duration);
            }
        }

        PackageManager pm = context.getPackageManager();
        for (Map.Entry<String, Long> entry : totalTime.entrySet()) {
            String pkg = entry.getKey();
            long duration = entry.getValue();
            if (duration < 1000) continue; // 过滤过短的无意义记录

            String appName;
            Drawable icon;
            try {
                ApplicationInfo appInfo = pm.getApplicationInfo(pkg, 0);
                appName = pm.getApplicationLabel(appInfo).toString();
                icon = pm.getApplicationIcon(appInfo);
            } catch (PackageManager.NameNotFoundException e) {
                continue; // 跳过已卸载或系统内部包
            }

            Integer count = launchCount.get(pkg);
            result.add(new AppUsage(pkg, appName, duration, count == null ? 0 : count, icon));
        }

        result.sort(new Comparator<AppUsage>() {
            @Override
            public int compare(AppUsage a, AppUsage b) {
                return Long.compare(b.totalTimeMillis, a.totalTimeMillis);
            }
        });

        if (result.isEmpty() && Constants.DEMO_MODE) {
            return getDemoAppUsage(context);
        }
        return result;
    }

    /**
     * 计算 0-23 点每小时的累计使用时长（毫秒），用于生成柱状图数据。
     */
    public static long[] getHourlyUsage(Context context) {
        long[] hourly = new long[24];
        if (!hasUsageStatsPermission(context)) {
            return Constants.DEMO_MODE ? getDemoHourlyUsage() : hourly;
        }

        long startTime = getStartOfToday();
        long endTime = System.currentTimeMillis();

        UsageStatsManager usm = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
        UsageEvents events = usm.queryEvents(startTime, endTime);

        Map<String, Long> foregroundStart = new HashMap<>();
        UsageEvents.Event event = new UsageEvents.Event();

        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            String pkg = event.getPackageName();
            int type = event.getEventType();

            if (type == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                foregroundStart.put(pkg, event.getTimeStamp());
            } else if (type == UsageEvents.Event.MOVE_TO_BACKGROUND) {
                Long start = foregroundStart.remove(pkg);
                if (start != null) {
                    addToHourlyBuckets(hourly, start, event.getTimeStamp(), startTime);
                }
            }
        }
        for (Long start : foregroundStart.values()) {
            addToHourlyBuckets(hourly, start, endTime, startTime);
        }

        boolean allZero = true;
        for (long v : hourly) {
            if (v > 0) { allZero = false; break; }
        }
        if (allZero && Constants.DEMO_MODE) {
            return getDemoHourlyUsage();
        }
        return hourly;
    }

    /** 将一段使用区间 [start, end) 按小时切分并累加到对应的桶中 */
    private static void addToHourlyBuckets(long[] hourly, long start, long end, long dayStart) {
        if (end <= start) return;
        long cursor = start;
        while (cursor < end) {
            int hour = (int) ((cursor - dayStart) / (60 * 60 * 1000L));
            if (hour < 0 || hour > 23) break;
            long hourBoundary = dayStart + (hour + 1) * 60 * 60 * 1000L;
            long segmentEnd = Math.min(end, hourBoundary);
            hourly[hour] += (segmentEnd - cursor);
            cursor = segmentEnd;
        }
    }

    /** 将毫秒格式化为 "X小时Y分" */
    public static String formatDuration(long millis) {
        long totalMinutes = millis / (60 * 1000);
        long hours = totalMinutes / 60;
        long minutes = totalMinutes % 60;
        if (hours > 0) {
            return hours + "小时" + minutes + "分";
        }
        return minutes + "分";
    }

    /** 简洁格式，例如 "1h32m"，用于排行卡片 */
    public static String formatDurationShort(long millis) {
        long totalMinutes = millis / (60 * 1000);
        long hours = totalMinutes / 60;
        long minutes = totalMinutes % 60;
        if (hours > 0) {
            return hours + "h" + minutes + "m";
        }
        return minutes + "m";
    }

    // ---------------- 内置演示模式数据 ----------------

    private static List<AppUsage> getDemoAppUsage(Context context) {
        List<AppUsage> demo = new ArrayList<>();
        PackageManager pm = context.getPackageManager();
        Object[][] fake = {
                {"com.tencent.mm", "WeChat", 92 * 60 * 1000L, 47},
                {"com.tencent.mobileqq", "QQ", 55 * 60 * 1000L, 21},
                {"com.zhiliaoapp.musically", "TikTok", 48 * 60 * 1000L, 15},
                {"com.google.android.youtube", "YouTube", 30 * 60 * 1000L, 9},
                {"com.android.chrome", "Chrome", 17 * 60 * 1000L, 12},
        };
        for (Object[] row : fake) {
            Drawable icon = null;
            try {
                icon = pm.getApplicationIcon((String) row[0]);
            } catch (PackageManager.NameNotFoundException ignored) {
                // 设备上未安装该应用时，图标留空，UI 层会使用占位图
            }
            demo.add(new AppUsage((String) row[0], (String) row[1], (Long) row[2], (Integer) row[3], icon));
        }
        return demo;
    }

    private static long[] getDemoHourlyUsage() {
        // 模拟一天的使用曲线，14 点为高峰
        int[] minutesByHour = {
                0, 0, 0, 0, 0, 0, 2, 8,
                15, 20, 18, 25, 22, 30, 42, 35,
                28, 20, 25, 32, 18, 10, 5, 2
        };
        long[] hourly = new long[24];
        for (int i = 0; i < 24; i++) {
            hourly[i] = minutesByHour[i] * 60 * 1000L;
        }
        return hourly;
    }
}
