package com.example.screentime;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.List;

/**
 * 首页 Fragment：承载总时长卡片、每小时分布图表卡片、应用排行卡片。
 */
public class HomeFragment extends Fragment {

    private TextView tvTotalTime;
    private TextView tvCompareText;
    private TextView tvPeakTime;
    private HistogramView histogramView;
    private LinearLayout rankingContainer;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvTotalTime = view.findViewById(R.id.tv_total_time);
        tvCompareText = view.findViewById(R.id.tv_compare_text);
        tvPeakTime = view.findViewById(R.id.tv_peak_time);
        histogramView = view.findViewById(R.id.histogram_view);
        rankingContainer = view.findViewById(R.id.layout_ranking_container);

        loadData();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData(); // 从系统设置页返回后自动刷新，保证权限授予后立刻生效
    }

    private void loadData() {
        if (getContext() == null) return;

        List<AppUsage> appUsageList = UsageStatsHelper.getTodayAppUsage(getContext());
        long[] hourly = UsageStatsHelper.getHourlyUsage(getContext());

        long totalMillis = 0;
        for (AppUsage app : appUsageList) {
            totalMillis += app.totalTimeMillis;
        }

        tvTotalTime.setText(UsageStatsHelper.formatDuration(totalMillis));
        tvCompareText.setText("较昨日减少 12%");

        histogramView.setData(hourly);
        int peakHour = histogramView.getPeakHour();
        if (peakHour >= 0) {
            tvPeakTime.setText(String.format("高峰 %02d:00", peakHour));
        }

        AppUsageAdapter.bindList(getContext(), rankingContainer, appUsageList, totalMillis);
    }
}
