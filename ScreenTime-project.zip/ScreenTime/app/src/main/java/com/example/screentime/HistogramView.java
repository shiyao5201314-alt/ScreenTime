package com.example.screentime;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * 自定义 24 小时柱状图组件，完全使用 Canvas 原生绘制，无第三方图表库依赖。
 * 除峰值柱子高亮为荧光绿外，其余柱子均为暗灰色；柱子底部带圆角；
 * X 轴无文字，仅底部绘制圆点刻度。
 */
public class HistogramView extends View {

    private long[] data = new long[24];
    private int peakIndex = -1;

    private final Paint barPaintInactive = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barPaintActive = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public HistogramView(Context context) {
        super(context);
        init();
    }

    public HistogramView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        barPaintInactive.setColor(0xFF333333);
        barPaintActive.setColor(0xFF9DFF00);
        dotPaint.setColor(0xFF555555);
    }

    /** 设置 24 小时的数据（毫秒），并自动计算峰值小时 */
    public void setData(long[] hourlyData) {
        this.data = hourlyData != null ? hourlyData : new long[24];
        this.peakIndex = 0;
        long max = 0;
        for (int i = 0; i < this.data.length; i++) {
            if (this.data[i] > max) {
                max = this.data[i];
                peakIndex = i;
            }
        }
        invalidate();
    }

    /** 返回峰值小时（0-23），供外部展示"高峰 XX:00" */
    public int getPeakHour() {
        return peakIndex;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (width == 0 || height == 0 || data == null) return;

        int barCount = data.length;
        float dotAreaHeight = height * 0.12f;
        float chartHeight = height - dotAreaHeight;
        float slotWidth = (float) width / barCount;
        float barWidth = slotWidth * 0.5f;
        float cornerRadius = barWidth / 2.5f;

        long max = 1;
        for (long v : data) {
            if (v > max) max = v;
        }

        for (int i = 0; i < barCount; i++) {
            float ratio = (float) data[i] / (float) max;
            float barHeight = Math.max(chartHeight * ratio, 4f);
            float left = i * slotWidth + (slotWidth - barWidth) / 2f;
            float right = left + barWidth;
            float bottom = chartHeight;
            float top = chartHeight - barHeight;

            Paint paint = (i == peakIndex && data[i] > 0) ? barPaintActive : barPaintInactive;
            RectF rect = new RectF(left, top, right, bottom);
            canvas.drawRoundRect(rect, cornerRadius, cornerRadius, paint);

            // 底部刻度圆点（X 轴无文字，仅圆点刻度）
            float dotY = chartHeight + dotAreaHeight / 2f;
            float dotX = i * slotWidth + slotWidth / 2f;
            canvas.drawCircle(dotX, dotY, 3f, dotPaint);
        }
    }
}
