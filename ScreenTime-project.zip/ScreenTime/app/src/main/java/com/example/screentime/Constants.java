package com.example.screentime;

/**
 * 全局配置类
 */
public class Constants {

    /**
     * 演示模式总开关（关键防空机制）。
     * 当此开关打开，且当前设备没有真实的可用监控数据（未授权或数据为空）时，
     * 全局会自动注入一组硬编码的模拟数据，确保安装后立刻能呈现完整的 UI 效果。
     * 正式发布时可将其设为 false，此时无权限将只显示空数据。
     */
    public static final boolean DEMO_MODE = true;
}
